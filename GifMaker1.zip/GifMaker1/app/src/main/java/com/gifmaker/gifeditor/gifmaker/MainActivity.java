package com.gifmaker.gifeditor.gifmaker;

import android.Manifest;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ShareCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gifmaker.gifeditor.gifmaker.adapters.MyGifsAdapter;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyGifsAdapter.OnItemClickedListener {

    Button mButton1;

    Button mButton3;
    RecyclerView mRecyclerView;
    MyGifsAdapter mMyGifsAdapter;
    File gifMaker;
    File[] files;
    boolean b2Clicked = false;


    int versionCode = BuildConfig.VERSION_CODE;
    String versionName = BuildConfig.VERSION_NAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButton1 = (Button) findViewById(R.id.button1);

        mButton3 = (Button) findViewById(R.id.button3);

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mRecyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 3));
        mRecyclerView.setHasFixedSize(true);

        gifMaker = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Gif Maker");
        if (!gifMaker.mkdir()) {
            Log.e("GifMakerActivity: ", "Directory doesn't exist");
        }

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    1);
        } else {
            files = gifMaker.listFiles();
            //Log.d("Gif: ", files[0].getAbsolutePath());
            mMyGifsAdapter = new MyGifsAdapter(files, MainActivity.this, this);
            mRecyclerView.setAdapter(mMyGifsAdapter);
        }

        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
            }
        });


        mButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[] {Manifest.permission.CAMERA},
                            2);
                } else {
                    Intent intent = new Intent("android.media.action.VIDEO_CAMERA");
                    startActivityForResult(intent, 2);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1:
                if ((grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    if (b2Clicked) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("video/*");
                        startActivityForResult(Intent.createChooser(intent, "Select Video"), 2);
                    } else {
                        files = gifMaker.listFiles();
                        mMyGifsAdapter = new MyGifsAdapter(files, MainActivity.this, this);
                        mRecyclerView.setAdapter(mMyGifsAdapter);
                    }
                } else {

                }
                break;
            case 2:
                if ((grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    Intent intent = new Intent("android.media.action.VIDEO_CAMERA");
                    startActivityForResult(intent, 2);
                } else {

                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) return;
        ArrayList<String> uris = new ArrayList<>();
        switch (requestCode) {
            case 1:
                ClipData clipData = data.getClipData();
                Uri uri;
                Uri singleUri = data.getData();
                if (clipData != null) {
                    int size = clipData.getItemCount();
                    for (int i = 0; i < size; i++) {
                        uri = clipData.getItemAt(i).getUri();
                        //Log.d("MainActivityClipdata: ", uri.toString());
                        uris.add(uri.toString());
                    }
                } else if (singleUri != null) {
                    //Log.d("MainActivityData: ", uri1.toString());
                    uris.add(singleUri.toString());
                }
                startActivity(new Intent(MainActivity.this, GifMakerActivity.class).putStringArrayListExtra("URIS", uris).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                break;
            case 2:
                Uri videoUri = data.getData();
                if (videoUri != null) {
                    Log.d("MainActivityData: ", videoUri.toString());
                    uris.add(videoUri.toString());
                }
                startActivity(new Intent(MainActivity.this, GifMakerActivity.class).putStringArrayListExtra("VIDEOURI", uris).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                break;
        }
    }

    @Override
    public void onItemClicked(int position) {
        startActivity(new Intent(MainActivity.this, GifMakerActivity.class).putExtra("GIFPATH",files[position].getAbsolutePath()).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        if (id == R.id.action_help) {



            Toast toast = Toast.makeText(this, "Mail Us For More Detail", Toast.LENGTH_LONG);
            View view = toast.getView();

            view.getBackground().setColorFilter((Color.parseColor("#FF104162")), PorterDuff.Mode.SRC_IN);


            TextView text = view.findViewById(android.R.id.message);
            text.setTextColor(Color.WHITE);

            toast.show();

            Intent send = new Intent(Intent.ACTION_SENDTO);
            String uriText = "mailto:" + Uri.encode("thexenonstudio@gmail.com") +
                    "?subject=" + Uri.encode("GIF - Help") +
                    "&body=" + Uri.encode("Hello, Type Your Query/Problem/Bug/Suggestions Here"+" \n\n\n ------------ \n\n Version Code : "+versionCode+"\n Version Name : "+versionName);
            Uri uri = Uri.parse(uriText);

            send.setData(uri);
            startActivity(Intent.createChooser(send, "Send Mail Via : "));
            return true;
        }
        if (id == R.id.action_sug) {



            Toast toast = Toast.makeText(this, "Mail Us For More Detail", Toast.LENGTH_LONG);
            View view = toast.getView();

            view.getBackground().setColorFilter((Color.parseColor("#FF104162")), PorterDuff.Mode.SRC_IN);


            TextView text = view.findViewById(android.R.id.message);
            text.setTextColor(Color.WHITE);

            toast.show();

            Intent send = new Intent(Intent.ACTION_SENDTO);
            String uriText = "mailto:" + Uri.encode("thexenonstudio@gmail.com") +
                    "?subject=" + Uri.encode("GIF - Suggestion") +
                    "&body=" + Uri.encode("Hello, Type Your Suggestions Here"+" \n\n\n ------------ \n\n Version Code : "+versionCode+"\n Version Name : "+versionName);
            Uri uri = Uri.parse(uriText);

            send.setData(uri);
            startActivity(Intent.createChooser(send, "Send Mail Via : "));
            return true;
        }

        if (id == R.id.nav_share) {



            ShareCompat.IntentBuilder.from(MainActivity.this)
                    .setType("text/plain")
                    .setChooserTitle("Share URL")
                    .setText("Hey, Download This Awesome GIF Maker App - https://xenonstudio.in/gifmaker \n")
                    .startChooser();




        }
        if (id == R.id.action_copy) {



          android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);

            builder.setIcon(R.drawable.gifmakerlogo);
            builder.setTitle("Privacy Policy ");
            builder.setPositiveButton("GOT IT", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                    dialogInterface.dismiss();
                }
            });
            builder.setNeutralButton("About Us", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    
                    dialogInterface.dismiss();
                    showaboutdialog();
                }
            });
            builder.setMessage("\n" +
                    "Gif Maker - Gif Video Creator is a Free app. This SERVICE is provided by Gif Maker at no cost and is intended for use as is.\n" +
                    "\n" +
                    "This page is used to inform visitors regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided to use my Service.\n" +
                    "\n" +
                    "If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving the Service. I will not use or share your information with anyone except as described in this Privacy Policy.\n" +
                    "\n" +
                    "The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at WahStickers unless otherwise defined in this Privacy Policy.\n" +
                    "\n" +
                    "Information Collection and Use\n" +
                    "\n" +
                    "For a better experience, while using our Service, I may require you to provide us with certain personally identifiable information. The information that I request will be retained on your device and is not collected by me in any way.\n" +
                    "\n" +
                    "The app does use third party services that may collect information used to identify you.\n" +
                    "\n" +
                    "Link to privacy policy of third party service providers used by the app\n" +
                    "\n" +
                    "Google Play Services\n" +
                    "Firebase Analytics\n" +
                    "Log Data\n" +
                    "\n" +
                    "I want to inform you that whenever you use my Service, in a case of an error in the app I collect data and information (through third party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing my Service, the time and date of your use of the Service, and other statistics.\n" +
                    "\n" +
                    "Cookies\n" +
                    "\n" +
                    "Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device's internal memory.\n" +
                    "\n" +
                    "This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.\n" +
                    "\n" +
                    "Service Providers\n" +
                    "\n" +
                    "I may employ third-party companies and individuals due to the following reasons:\n" +
                    "\n" +
                    "To facilitate our Service;\n" +
                    "To provide the Service on our behalf;\n" +
                    "To perform Service-related services; or\n" +
                    "To assist us in analyzing how our Service is used.\n" +
                    "I want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.\n" +
                    "\n" +
                    "Security\n" +
                    "\n" +
                    "I value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.\n" +
                    "\n" +
                    "Links to Other Sites\n" +
                    "\n" +
                    "This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by me. Therefore, I strongly advise you to review the Privacy Policy of these websites. I have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.\n" +
                    "\n" +
                    "Children’s Privacy\n" +
                    "\n" +
                    "These Services do not address anyone under the age of 13. I do not knowingly collect personally identifiable information from children under 13. In the case I discover that a child under 13 has provided me with personal information, I immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact me so that I will be able to do necessary actions.\n" +
                    "\n" +
                    "Changes to This Privacy Policy\n" +
                    "\n" +
                    "I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page.\n" +
                    "\n" +
                    "Contact Us\n" +
                    "\n" +
                    "If you have any questions or suggestions about Privacy Policy, do not hesitate to contact us at " +
                    "barry@uptodownapp.com.");

            android.app.AlertDialog dialog = builder.create();
            dialog.show();



        }


        return super.onOptionsItemSelected(item);
    }

    private void showaboutdialog() {

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);

        builder.setMessage("We Are Making App More Easier, UI Friendly and More Secure \n\nApp Developed By Xenon Studio,\n\nApp Managed By UptoDown Apps Studio\n\n For More - https://xenonstudio.in/gifmaker");

        builder.setPositiveButton("GOT IT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                dialogInterface.dismiss();
            }
        }).setNegativeButton("Developer Contact", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                Intent send = new Intent(Intent.ACTION_SENDTO);
                String uriText = "mailto:" + Uri.encode("thexenonstudio@gmail.com") +
                        "?subject=" + Uri.encode("Notification Log - Developer Contact") +
                        "&body=" + Uri.encode("Hello, Type Your Query/Problem/Bug/Suggestions Here"+" \n\n\n ------------ \n\n Version Code : "+versionCode+"\n Version Name : "+versionName);
                Uri uri = Uri.parse(uriText);

                send.setData(uri);
                startActivity(Intent.createChooser(send, "Send Mail Via : "));
            }
        }).setNeutralButton("Manager Contact", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                Intent send = new Intent(Intent.ACTION_SENDTO);
                String uriText = "mailto:" + Uri.encode("barry@uptodownapp.com") +
                        "?subject=" + Uri.encode("GIF Maker App - Contact") +
                        "&body=" + Uri.encode("Hello, Type Your Query/Problem/Bug/Suggestions Here"+" \n\n\n ------------ \n\n Version Code : "+versionCode+"\n Version Name : "+versionName);
                Uri uri = Uri.parse(uriText);

                send.setData(uri);
                startActivity(Intent.createChooser(send, "Send Mail Via : "));
            }
        });

        android.app.AlertDialog dialog = builder.create();
        dialog.show();
    }



    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage("Do You Want To Exit The App?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .show();
    }

}
